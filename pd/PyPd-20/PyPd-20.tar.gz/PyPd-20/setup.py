from setuptools import setup

setup(
    name = 'PyPd',
    version = "5",
    #packages = [""],
    #scripts = ["scripts/"],
)
